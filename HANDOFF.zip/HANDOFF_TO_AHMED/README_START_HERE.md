# 🚀 START HERE - Project Handoff to Ahmed Eldarawi

**Date**: April 12, 2026  
**From**: Ahmody Ossama (ahmody.ossama@gmail.com)  
**To**: Ahmed Eldarawi (ahmedd.eldarawi@gmail.com)  
**Project**: ML-Based Autoscaling for Microservices (grad-phca)

---

## 📋 What's in This Folder

1. **README_START_HERE.md** ← You are here
2. **ACCESS_GRANTED_SUMMARY.md** - Your GCP access details
3. **GRADMATE_ACCESS_SETUP.md** - Complete setup instructions
4. **PROJECT_STATUS.md** - Current state of the project
5. **DATABASE_SCALING_PLAN.md** - Database bottleneck findings
6. **CONVERGENCE_TEST_PLAN.md** - Test methodology
7. **DATABASE_BOTTLENECK_ANALYSIS.md** - Detailed analysis
8. **google_compute_engine** - SSH private key (KEEP SECURE!)
9. **google_compute_engine.pub** - SSH public key

---

## ⚡ Quick Start (Do This First)

### Step 1: Install Tools (15 minutes)
```bash
# Install gcloud CLI
# Windows: https://cloud.google.com/sdk/docs/install
# Mac: brew install google-cloud-sdk
# Linux: curl https://sdk.cloud.google.com | bash

# Install kubectl
gcloud components install kubectl

# Install Python dependencies
pip install kubernetes requests locust google-cloud-storage
```

### Step 2: Authenticate (5 minutes)
```bash
# Login with YOUR email
gcloud auth login ahmedd.eldarawi@gmail.com

# Set project
gcloud config set project grad-phca

# Get cluster credentials
gcloud container clusters get-credentials pipeline-cluster \
    --zone=us-central1-a \
    --project=grad-phca
```

### Step 3: Verify Access (2 minutes)
```bash
# Test GCP access
gcloud projects describe grad-phca

# Test Kubernetes access
kubectl get nodes
kubectl get pods -n sock-shop

# Test Compute Engine access
gcloud compute instances list
```

### Step 4: Setup SSH Key (3 minutes)
```bash
# Copy the SSH key to your .ssh folder
# Windows:
mkdir $env:USERPROFILE\.ssh
copy google_compute_engine $env:USERPROFILE\.ssh\
copy google_compute_engine.pub $env:USERPROFILE\.ssh\

# Mac/Linux:
mkdir -p ~/.ssh
cp google_compute_engine ~/.ssh/
cp google_compute_engine.pub ~/.ssh/
chmod 600 ~/.ssh/google_compute_engine

# Test SSH to Locust VM
ssh -i ~/.ssh/google_compute_engine User@35.222.116.125
```

### Step 5: Clone Repository
```bash
# Get repository URL from Ahmody
git clone REPO_URL
cd REPO_NAME
```

---

## 🎯 What You Can Do Now

### Full Access To:
- ✅ All GKE clusters (pipeline-cluster)
- ✅ All Compute Engine VMs (Locust VM)
- ✅ All Kubernetes resources (pods, deployments, services)
- ✅ Docker Container Registry
- ✅ Cloud Storage
- ✅ Monitoring (Prometheus, logs)
- ✅ IAM policies

### Key Commands:
```bash
# View all resources
kubectl get all -n sock-shop
kubectl get all -n kafka

# Scale services
kubectl scale deployment front-end -n sock-shop --replicas=5

# View logs
kubectl logs -f deployment/front-end -n sock-shop

# SSH to Locust VM
ssh -i ~/.ssh/google_compute_engine User@35.222.116.125

# Run experiments
cd kafka-structured/experiments
python run_experiments.py
```

---

## 📊 Project Overview

### What This Project Does
ML-based autoscaling system for microservices that:
1. Collects metrics from Kubernetes services
2. Uses ML models (SVM, Random Forest, Logistic Regression) to predict scaling needs
3. Automatically scales services based on predictions
4. Compares against baseline HPA (Horizontal Pod Autoscaler)

### Architecture
```
Sock Shop (Microservices)
    ↓ metrics
Prometheus
    ↓ queries
Metrics Aggregator
    ↓ publishes
Kafka
    ↓ consumes
ML Inference Services (SVM, RF, LR)
    ↓ predictions
Kafka
    ↓ consumes
Authoritative Scaler
    ↓ decisions
Kafka
    ↓ consumes
Scaling Controller
    ↓ scales
Kubernetes API
```

### Key Services
- **Sock Shop**: E-commerce microservices (front-end, carts, orders, etc.)
- **ML Models**: 3 models making scaling predictions
- **Kafka**: Message bus for the pipeline
- **Prometheus**: Metrics collection
- **Locust**: Load testing

---

## 🔥 Current Status & Recent Findings

### ✅ What's Working
- GKE clusters running and healthy
- Sock Shop deployed with 7 services
- ML inference services deployed (SVM, LR, RF)
- Kafka pipeline functional
- Prometheus monitoring active
- Load testing with Locust working

### 🎯 Major Discovery (IMPORTANT!)
**Database Bottleneck Identified and Fixed**

**Problem**: Scaling services (carts, orders) from 1→5 replicas had NO effect or even WORSENED latency because databases (carts-db, orders-db) were bottlenecked at 1-2 replicas.

**Evidence**:
- Orders: Scaling 1→5 replicas INCREASED p95 by 106% (58.7ms → 120.8ms)
- Carts: Scaling 1→5 replicas only improved p95 by 16%

**Solution**: Scaled databases to 3 replicas

**Result**:
- Carts: Now 33% improvement when scaling (53.2ms → 35.5ms)
- Orders: Now 45% improvement when scaling (78.7ms → 43.7ms)

**Read**: `DATABASE_BOTTLENECK_ANALYSIS.md` for full details

### ⚠️ Known Issues
1. **36ms SLO too aggressive**: May need adjustment to 50-60ms for database-backed services
2. **Prometheus timeouts**: Under heavy load, Prometheus can timeout (5s → 15s timeout needed)
3. **Test timing bug**: Fixed - need 21 minutes Locust for 40 snapshots (not 20 minutes)
4. **Application errors**: ~5% error rate from Locust test design (race conditions)

---

## 📁 Important Files & Locations

### GCP Resources
- **Project ID**: grad-phca
- **Cluster**: pipeline-cluster (us-central1-a)
- **Locust VM**: 35.222.116.125
- **Prometheus**: 34.170.213.190:9090
- **Sock Shop**: 104.154.246.88

### Repository Structure
```
kafka-structured/
├── experiments/
│   ├── run_experiments.py          # Main experiment runner
│   ├── run_config.py                # Experiment configuration
│   └── results/                     # Test results (JSONL files)
├── services/
│   ├── ml-inference/                # ML inference service
│   ├── metrics-aggregator/          # Collects metrics
│   ├── authoritative-scaler/        # Makes scaling decisions
│   └── scaling-controller/          # Executes scaling
├── ML-Models/
│   ├── models/                      # Trained models
│   └── gke/                         # Training scripts
├── load-testing/
│   └── src/
│       ├── locustfile_constant.py   # Constant load pattern
│       ├── locustfile_step.py       # Step load pattern
│       └── locustfile_ramp.py       # Ramp load pattern
└── k8s/
    ├── hpa-baseline.yaml            # Baseline HPA config
    └── deployments/                 # Kubernetes manifests
```

### Key Configuration Files
- `kafka-structured/experiments/run_config.py` - SLO threshold (36ms), services list
- `kafka-structured/load-testing/src/locustfile_constant.py` - Load test config (150 users)
- `kafka-structured/services/ml-inference/inference.py` - ML model inference logic

---

## 🧪 How to Run Experiments

### Quick Test (10 minutes)
```bash
cd kafka-structured/experiments

# Edit run_config.py to set repetitions
# REPETITIONS = {"constant": 1, "step": 0, "spike": 0, "ramp": 0}

# Run
python run_experiments.py
```

### Full Experiment Suite (7 hours)
```bash
cd kafka-structured/experiments

# Run all patterns with repetitions
python run_experiments.py --pause-before-start
```

### Manual Test
```bash
# 1. Reset services
kubectl scale deployment front-end carts orders catalogue user payment shipping \
    -n sock-shop --replicas=1

# 2. Start load test
ssh -i ~/.ssh/google_compute_engine User@35.222.116.125
source ~/locust-venv/bin/activate
LOCUST_RUN_TIME_MINUTES=10 locust -f ~/locustfile_constant.py --headless --run-time 10m --host http://104.154.246.88

# 3. Monitor
kubectl get pods -n sock-shop -w
```

---

## 🎓 Next Steps for Your Work

### Immediate Tasks
1. ✅ Setup access (follow steps above)
2. ⏳ Read all documentation files
3. ⏳ Run a test experiment to verify everything works
4. ⏳ Review recent test results in `kafka-structured/experiments/results/`

### Research Tasks
1. **Convergence Testing**: Run 20-minute tests to show system reaches steady state
2. **SLO Adjustment**: Determine appropriate SLO for database-backed services
3. **Database Autoscaling**: Consider adding databases to autoscaling system
4. **Comparison Analysis**: Compare proactive vs reactive across all load patterns
5. **Paper Writing**: Document findings and results

### Suggested Order
1. Run convergence test (20 min) with current setup
2. Analyze if violations converge to <10% in final 5 minutes
3. If not, adjust SLO or scale databases further
4. Run full experiment suite (all patterns, both conditions)
5. Analyze results and write paper

---

## 📞 Contact & Support

### If You Get Stuck
1. Check the documentation files in this folder
2. Review error messages carefully
3. Check Kubernetes logs: `kubectl logs -f deployment/SERVICE -n NAMESPACE`
4. Check Prometheus: http://34.170.213.190:9090

### Useful Commands for Debugging
```bash
# Check pod status
kubectl get pods -n sock-shop
kubectl describe pod POD_NAME -n sock-shop

# Check logs
kubectl logs -f deployment/front-end -n sock-shop
kubectl logs -f deployment/ml-inference-svm -n kafka

# Check metrics
curl http://34.170.213.190:9090/api/v1/query?query=up

# Check service endpoints
kubectl get svc -n sock-shop
```

### GCP Console
- https://console.cloud.google.com/
- Project: grad-phca

---

## 🔒 Security Reminders

1. **Keep SSH key secure** - Don't share or commit to Git
2. **Don't commit credentials** - Use .gitignore
3. **Monitor costs** - Check GCP billing regularly
4. **Shut down resources** when not in use to save costs

### Cost-Saving Tips
```bash
# Stop Locust VM when not testing
gcloud compute instances stop locust-runner --zone=us-central1-a

# Scale down clusters when not in use
gcloud container clusters resize pipeline-cluster --num-nodes=1 --zone=us-central1-a

# Start them back up when needed
gcloud compute instances start locust-runner --zone=us-central1-a
gcloud container clusters resize pipeline-cluster --num-nodes=3 --zone=us-central1-a
```

---

## ✅ Verification Checklist

Before starting work, verify:
- [ ] gcloud CLI installed and authenticated
- [ ] kubectl installed and configured
- [ ] Can access GCP console
- [ ] Can list GKE clusters
- [ ] Can list pods in sock-shop namespace
- [ ] Can SSH to Locust VM
- [ ] Repository cloned
- [ ] Python dependencies installed
- [ ] Can run `python run_experiments.py --help`

---

**Good luck with your research! 🚀**

If you have questions, reach out to Ahmody at ahmody.ossama@gmail.com
