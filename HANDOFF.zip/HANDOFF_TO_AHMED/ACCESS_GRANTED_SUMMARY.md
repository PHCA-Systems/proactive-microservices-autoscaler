# Access Granted to Ahmed Eldarawi

## ✅ Completed Setup

### GCP Project Access
**Email**: ahmedd.eldarawi@gmail.com  
**Project**: grad-phca

**Roles Granted**:
- ✅ `roles/editor` - Full access to all resources (except billing/IAM)
- ✅ `roles/compute.admin` - Full Compute Engine access
- ✅ `roles/container.admin` - Full GKE access
- ✅ `roles/resourcemanager.projectIamAdmin` - Can manage IAM policies

### Kubernetes Cluster Access
- ✅ `cluster-admin` role on pipeline-cluster (us-central1-a)

---

## What Ahmed Can Do Now

### Full Access To:
- ✅ All GKE clusters (create, delete, modify)
- ✅ All Compute Engine VMs (start, stop, SSH, modify)
- ✅ All Kubernetes resources (pods, deployments, services, etc.)
- ✅ Docker images in Container Registry (push, pull, delete)
- ✅ Cloud Storage buckets
- ✅ Networking (VPCs, firewall rules, load balancers)
- ✅ Monitoring and logging
- ✅ IAM policies (can grant access to others)

### Commands He Can Run:
```bash
# View all resources
gcloud compute instances list
gcloud container clusters list
kubectl get pods --all-namespaces

# Manage clusters
gcloud container clusters resize pipeline-cluster --num-nodes=5
kubectl scale deployment front-end -n sock-shop --replicas=10

# SSH to VMs (needs SSH key)
ssh -i ~/.ssh/google_compute_engine User@35.222.116.125

# Push Docker images
docker push gcr.io/grad-phca/my-image:latest

# Run experiments
cd kafka-structured/experiments
python run_experiments.py
```

---

## What Ahmed Needs to Do

### 1. Install Tools
```bash
# Install gcloud CLI
# Windows: https://cloud.google.com/sdk/docs/install
# Mac: brew install google-cloud-sdk

# Install kubectl
gcloud components install kubectl

# Install Python dependencies
pip install kubernetes requests locust google-cloud-storage
```

### 2. Authenticate
```bash
# Login with his email
gcloud auth login ahmedd.eldarawi@gmail.com

# Set project
gcloud config set project grad-phca

# Get cluster credentials
gcloud container clusters get-credentials pipeline-cluster \
    --zone=us-central1-a \
    --project=grad-phca

# Verify access
kubectl get nodes
```

### 3. Get SSH Key for Locust VM
You need to share your SSH key with him:
```bash
# Location: ~/.ssh/google_compute_engine
# Send him this file securely (encrypted email, USB, etc.)
```

Or generate a new key for him:
```bash
# On his machine
ssh-keygen -t rsa -f ~/.ssh/ahmedd_gcp_key -C "ahmedd.eldarawi@gmail.com"

# Then you add his public key to the VM
gcloud compute instances add-metadata locust-runner \
    --zone=us-central1-a \
    --metadata-from-file ssh-keys=<(echo "User:$(cat ~/.ssh/ahmedd_gcp_key.pub)")
```

### 4. Clone Repository
```bash
git clone YOUR_REPO_URL
cd YOUR_REPO
```

---

## Important Resources

### Cluster Information
- **Pipeline Cluster**: gke_grad-phca_us-central1-a_pipeline-cluster
- **Zone**: us-central1-a
- **Project ID**: grad-phca

### VM Information
- **Locust VM**: 35.222.116.125
- **Prometheus**: 34.170.213.190:9090
- **Sock Shop**: 104.154.246.88

### Key Services
- **Namespace**: sock-shop, kafka, monitoring
- **Services**: front-end, carts, orders, catalogue, user, payment, shipping
- **Databases**: carts-db (3 replicas), orders-db (3 replicas)

---

## Verification Commands

Have Ahmed run these to verify access:

```bash
# 1. GCP access
gcloud projects describe grad-phca

# 2. Compute Engine
gcloud compute instances list

# 3. GKE clusters
gcloud container clusters list

# 4. Kubernetes
kubectl get nodes
kubectl get pods -n sock-shop
kubectl get deployments -n sock-shop

# 5. Docker registry
gcloud auth configure-docker
docker pull gcr.io/grad-phca/ml-inference:latest

# 6. SSH to Locust VM
ssh -i ~/.ssh/google_compute_engine User@35.222.116.125 "echo 'SSH works'"
```

---

## Files to Share with Ahmed

1. ✅ `GRADMATE_ACCESS_SETUP.md` - Complete setup guide
2. ✅ `ACCESS_GRANTED_SUMMARY.md` - This file
3. ⚠️ SSH key: `~/.ssh/google_compute_engine` (send securely)
4. ⚠️ Repository URL or zip file
5. ⚠️ Any custom configuration files

---

## Security Notes

### What Ahmed CANNOT Do:
- ❌ Manage billing (view only)
- ❌ Delete the project
- ❌ Grant Owner role to others (only Editor and below)

### Monitoring His Activity:
```bash
# View his actions
gcloud logging read "protoPayload.authenticationInfo.principalEmail=ahmedd.eldarawi@gmail.com" \
    --limit 50
```

### Revoke Access Later:
```bash
# Remove all roles
gcloud projects remove-iam-policy-binding grad-phca \
    --member="user:ahmedd.eldarawi@gmail.com" \
    --role="roles/editor"

gcloud projects remove-iam-policy-binding grad-phca \
    --member="user:ahmedd.eldarawi@gmail.com" \
    --role="roles/compute.admin"

gcloud projects remove-iam-policy-binding grad-phca \
    --member="user:ahmedd.eldarawi@gmail.com" \
    --role="roles/container.admin"

# Remove Kubernetes access
kubectl delete clusterrolebinding ahmedd-cluster-admin \
    --context=gke_grad-phca_us-central1-a_pipeline-cluster
```

---

## Next Steps

1. ✅ Access granted (DONE)
2. ⏳ Share SSH key with Ahmed
3. ⏳ Share repository access
4. ⏳ Have Ahmed verify access using commands above
5. ⏳ Brief Ahmed on current project status

---

## Current Project Status

### What's Working:
- ✅ GKE clusters running
- ✅ Sock Shop deployed
- ✅ ML inference services (SVM, LR, RF) deployed
- ✅ Kafka pipeline functional
- ✅ Prometheus monitoring active
- ✅ Databases scaled (carts-db=3, orders-db=3)

### Recent Findings:
- ✅ Database bottleneck identified and fixed
- ✅ Scaling databases improved service scaling effectiveness
- ✅ Carts: 33% improvement, Orders: 45% improvement with DB scaling

### What Needs Work:
- ⚠️ 36ms SLO may be too aggressive for database-backed services
- ⚠️ Need longer convergence tests (20+ minutes)
- ⚠️ Prometheus timeout issues during heavy load

### Files Ahmed Should Read:
- `DATABASE_SCALING_PLAN.md` - Database bottleneck analysis
- `CONVERGENCE_TEST_PLAN.md` - Test methodology
- `kafka-structured/experiments/run_experiments.py` - Main experiment runner

---

**Setup completed on**: 2026-04-12  
**Your email**: ahmody.ossama@gmail.com  
**Ahmed's email**: ahmedd.eldarawi@gmail.com
