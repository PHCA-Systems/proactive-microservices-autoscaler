# Gradmate Access Setup Guide
## Granting Full Access to: ahmedd.eldarawi@gmail.com

This guide provides ALL commands needed to grant your gradmate complete access to your GCP project, clusters, and resources.

---

## 1. GCP Project Access (CRITICAL - Do This First)

### Add as Project Owner
```bash
# Grant Owner role (full access to everything)
gcloud projects add-iam-policy-binding grad-phca \
    --member="user:ahmedd.eldarawi@gmail.com" \
    --role="roles/owner"

# Verify the binding
gcloud projects get-iam-policy grad-phca \
    --flatten="bindings[].members" \
    --filter="bindings.members:ahmedd.eldarawi@gmail.com"
```

### Alternative: Grant Specific Roles (if you don't want full Owner)
```bash
# Compute Admin (for VMs, networks)
gcloud projects add-iam-policy-binding grad-phca \
    --member="user:ahmedd.eldarawi@gmail.com" \
    --role="roles/compute.admin"

# Kubernetes Engine Admin (for GKE clusters)
gcloud projects add-iam-policy-binding grad-phca \
    --member="user:ahmedd.eldarawi@gmail.com" \
    --role="roles/container.admin"

# Storage Admin (for GCS buckets, images)
gcloud projects add-iam-policy-binding grad-phca \
    --member="user:ahmedd.eldarawi@gmail.com" \
    --role="roles/storage.admin"

# Service Account Admin (for managing service accounts)
gcloud projects add-iam-policy-binding grad-phca \
    --member="user:ahmedd.eldarawi@gmail.com" \
    --role="roles/iam.serviceAccountAdmin"

# Logging Admin (for viewing logs)
gcloud projects add-iam-policy-binding grad-phca \
    --member="user:ahmedd.eldarawi@gmail.com" \
    --role="roles/logging.admin"

# Monitoring Admin (for Prometheus, metrics)
gcloud projects add-iam-policy-binding grad-phca \
    --member="user:ahmedd.eldarawi@gmail.com" \
    --role="roles/monitoring.admin"
```

---

## 2. GKE Cluster Access

### Grant Cluster Admin Access
```bash
# For pipeline-cluster
kubectl create clusterrolebinding ahmedd-cluster-admin \
    --clusterrole=cluster-admin \
    --user=ahmedd.eldarawi@gmail.com \
    --context=gke_grad-phca_us-central1-a_pipeline-cluster

# For sock-shop cluster (if separate)
kubectl create clusterrolebinding ahmedd-cluster-admin-sockshop \
    --clusterrole=cluster-admin \
    --user=ahmedd.eldarawi@gmail.com
```

### Verify Access
```bash
# Check if binding exists
kubectl get clusterrolebinding ahmedd-cluster-admin -o yaml
```

---

## 3. Compute Engine VM Access (Locust VM)

### Grant SSH Access to Locust VM
```bash
# Add SSH key to VM metadata
gcloud compute instances add-metadata locust-runner \
    --zone=us-central1-a \
    --metadata-from-file ssh-keys=<(echo "ahmedd.eldarawi:$(cat ~/.ssh/id_rsa.pub)")

# Or add to project-wide SSH keys
gcloud compute project-info add-metadata \
    --metadata-from-file ssh-keys=<(gcloud compute project-info describe \
    --format="value(commonInstanceMetadata.items.filter(key:ssh-keys).value)" && \
    echo "ahmedd.eldarawi:$(cat ~/.ssh/id_rsa.pub)")
```

### Alternative: Share Your SSH Key
```bash
# Copy your SSH key to a shared location
cp ~/.ssh/google_compute_engine /path/to/shared/location/
cp ~/.ssh/google_compute_engine.pub /path/to/shared/location/

# Or generate a new key for him
ssh-keygen -t rsa -f ~/.ssh/ahmedd_gcp_key -C "ahmedd.eldarawi@gmail.com"

# Add his key to the VM
gcloud compute instances add-metadata locust-runner \
    --zone=us-central1-a \
    --metadata-from-file ssh-keys=<(echo "User:$(cat ~/.ssh/ahmedd_gcp_key.pub)")
```

---

## 4. GitHub Repository Access

### Add as Collaborator
1. Go to: https://github.com/YOUR_USERNAME/YOUR_REPO/settings/access
2. Click "Add people"
3. Enter: ahmedd.eldarawi@gmail.com
4. Select role: "Admin" (full access)

### Or via Command Line (if using GitHub CLI)
```bash
gh repo add-collaborator YOUR_USERNAME/YOUR_REPO ahmedd.eldarawi --permission admin
```

---

## 5. Service Account Keys (for Programmatic Access)

### Create Service Account for Him
```bash
# Create service account
gcloud iam service-accounts create ahmedd-sa \
    --display-name="Ahmed Eldarawi Service Account"

# Grant necessary roles
gcloud projects add-iam-policy-binding grad-phca \
    --member="serviceAccount:ahmedd-sa@grad-phca.iam.gserviceaccount.com" \
    --role="roles/owner"

# Create and download key
gcloud iam service-accounts keys create ~/ahmedd-sa-key.json \
    --iam-account=ahmedd-sa@grad-phca.iam.gserviceaccount.com

# Share this key file with him securely
```

---

## 6. Docker Registry Access (GCR)

### Grant Container Registry Access
```bash
# Grant Storage Admin (GCR uses GCS)
gcloud projects add-iam-policy-binding grad-phca \
    --member="user:ahmedd.eldarawi@gmail.com" \
    --role="roles/storage.admin"

# Or specific GCR role
gsutil iam ch user:ahmedd.eldarawi@gmail.com:objectAdmin gs://artifacts.grad-phca.appspot.com
```

---

## 7. Firewall Rules (if needed)

### Allow His IP Address
```bash
# Get his IP and add to firewall rule
gcloud compute firewall-rules update allow-ssh \
    --source-ranges=HIS_IP_ADDRESS/32

# Or create new rule for him
gcloud compute firewall-rules create ahmedd-access \
    --allow=tcp:22,tcp:80,tcp:443,tcp:9090 \
    --source-ranges=HIS_IP_ADDRESS/32 \
    --description="Access for Ahmed Eldarawi"
```

---

## 8. What He Needs to Do on His Machine

### Install Required Tools
```bash
# Install gcloud CLI
# Windows: https://cloud.google.com/sdk/docs/install
# Mac: brew install google-cloud-sdk
# Linux: curl https://sdk.cloud.google.com | bash

# Install kubectl
gcloud components install kubectl

# Install Python dependencies
pip install kubernetes requests locust google-cloud-storage
```

### Authenticate with GCP
```bash
# Login with his email
gcloud auth login ahmedd.eldarawi@gmail.com

# Set project
gcloud config set project grad-phca

# Get cluster credentials
gcloud container clusters get-credentials pipeline-cluster \
    --zone=us-central1-a \
    --project=grad-phca

# Verify access
kubectl get nodes
kubectl get pods -n sock-shop
```

### Clone Repository
```bash
git clone https://github.com/YOUR_USERNAME/YOUR_REPO.git
cd YOUR_REPO
```

### Test SSH to Locust VM
```bash
# Using shared key
ssh -i ~/.ssh/google_compute_engine User@35.222.116.125

# Or his own key
ssh -i ~/.ssh/ahmedd_gcp_key User@35.222.116.125
```

---

## 9. Share Configuration Files

### Files to Share with Him
```bash
# GCP credentials
~/.config/gcloud/

# Kubernetes config
~/.kube/config

# SSH keys
~/.ssh/google_compute_engine
~/.ssh/google_compute_engine.pub

# Project files
D:\Projects\Grad\PHCA\
```

### Secure Transfer Methods
- Google Drive (encrypted)
- Encrypted USB drive
- Secure file sharing service (e.g., Keybase, Signal)

---

## 10. Verification Checklist

Have him run these commands to verify access:

```bash
# GCP Project Access
gcloud projects describe grad-phca

# GKE Cluster Access
kubectl get nodes
kubectl get pods --all-namespaces

# Compute Engine Access
gcloud compute instances list

# SSH to Locust VM
ssh -i ~/.ssh/google_compute_engine User@35.222.116.125 "echo 'SSH works'"

# Docker Registry Access
gcloud auth configure-docker
docker pull gcr.io/grad-phca/ml-inference:latest

# Run experiment
cd kafka-structured/experiments
python run_experiments.py --help
```

---

## 11. Important Notes

### Security Best Practices
1. **Use separate service accounts** instead of sharing your personal credentials
2. **Enable 2FA** on his Google account
3. **Audit access regularly**: `gcloud projects get-iam-policy grad-phca`
4. **Revoke access when done**: See section 12 below

### Cost Management
1. Set up billing alerts for his usage
2. Grant "Billing Account Viewer" role:
   ```bash
   gcloud beta billing accounts add-iam-policy-binding BILLING_ACCOUNT_ID \
       --member="user:ahmedd.eldarawi@gmail.com" \
       --role="roles/billing.viewer"
   ```

### Monitoring His Activity
```bash
# View audit logs
gcloud logging read "protoPayload.authenticationInfo.principalEmail=ahmedd.eldarawi@gmail.com" \
    --limit 50 \
    --format json
```

---

## 12. How to Revoke Access (When Project Ends)

### Remove All Permissions
```bash
# Remove from project
gcloud projects remove-iam-policy-binding grad-phca \
    --member="user:ahmedd.eldarawi@gmail.com" \
    --role="roles/owner"

# Remove cluster access
kubectl delete clusterrolebinding ahmedd-cluster-admin

# Remove from GitHub
gh repo remove-collaborator YOUR_USERNAME/YOUR_REPO ahmedd.eldarawi

# Delete service account
gcloud iam service-accounts delete ahmedd-sa@grad-phca.iam.gserviceaccount.com

# Remove SSH access
gcloud compute instances remove-metadata locust-runner \
    --zone=us-central1-a \
    --keys=ssh-keys
```

---

## Quick Start Commands (Run These Now)

```bash
# 1. Grant Owner access (EASIEST - full permissions)
gcloud projects add-iam-policy-binding grad-phca \
    --member="user:ahmedd.eldarawi@gmail.com" \
    --role="roles/owner"

# 2. Grant cluster admin
kubectl create clusterrolebinding ahmedd-cluster-admin \
    --clusterrole=cluster-admin \
    --user=ahmedd.eldarawi@gmail.com \
    --context=gke_grad-phca_us-central1-a_pipeline-cluster

# 3. Verify
gcloud projects get-iam-policy grad-phca | grep ahmedd.eldarawi

# 4. Send him this file and the repository link
```

---

## Contact Info
- Your Email: [YOUR_EMAIL]
- His Email: ahmedd.eldarawi@gmail.com
- Project ID: grad-phca
- Clusters: pipeline-cluster (us-central1-a)
- Locust VM: 35.222.116.125
- Prometheus: 34.170.213.190:9090
- Sock Shop: 104.154.246.88
