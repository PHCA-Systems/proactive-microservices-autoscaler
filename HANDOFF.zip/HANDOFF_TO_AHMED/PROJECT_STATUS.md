# Project Status - April 12, 2026

## 🎯 Project Goal
Develop and evaluate an ML-based proactive autoscaling system for microservices that outperforms reactive HPA (Horizontal Pod Autoscaler).

---

## ✅ Completed Work

### 1. Infrastructure Setup
- ✅ GKE cluster deployed (pipeline-cluster, us-central1-a)
- ✅ Sock Shop microservices deployed (7 services)
- ✅ Prometheus monitoring configured
- ✅ Kafka message bus deployed
- ✅ Locust load testing VM configured

### 2. ML Pipeline Implementation
- ✅ Metrics Aggregator service (collects from Prometheus)
- ✅ ML Inference services (SVM, Random Forest, Logistic Regression)
- ✅ Authoritative Scaler (aggregates predictions)
- ✅ Scaling Controller (executes scaling decisions)
- ✅ Full Kafka-based pipeline functional

### 3. ML Models Trained & Deployed
- ✅ SVM model (93% accuracy)
- ✅ Logistic Regression with one-hot encoding (93.14% accuracy)
- ✅ Random Forest with one-hot encoding (95.24% accuracy)
- ✅ All models deployed to GKE with Docker images
- ✅ Feature engineering fixed (service_0 through service_6)

### 4. Load Testing
- ✅ Locust load patterns implemented:
  - Constant load (150 users)
  - Step load
  - Ramp load
  - Spike load
- ✅ Load test VM configured and working
- ✅ Realistic e-commerce traffic patterns

### 5. Experiment Framework
- ✅ Automated experiment runner (`run_experiments.py`)
- ✅ Metrics collection every 30 seconds
- ✅ JSONL result format
- ✅ Proactive vs Reactive comparison framework

### 6. Major Debugging & Fixes
- ✅ Fixed Redis session-db read-only filesystem issue (78-94% error reduction)
- ✅ Added RPS gate to prevent spurious scaling at no-load
- ✅ Fixed timing bug (Locust duration vs snapshot collection)
- ✅ Identified and fixed database bottleneck
- ✅ Scaled databases (carts-db=3, orders-db=3)
- ✅ Fixed Unicode encoding issues in experiment runner

---

## 🔬 Key Findings

### Finding 1: Database Bottleneck (CRITICAL)
**Discovery**: Scaling application services had minimal or negative effect on latency because databases were bottlenecked.

**Evidence**:
- Orders service: Scaling 1→5 replicas INCREASED p95 by 106% (58.7ms → 120.8ms)
- Carts service: Scaling 1→5 replicas only improved p95 by 16% (61.3ms → 51.5ms)
- Front-end (no database): Scaling 2→5 replicas improved p95 by 17% (proper behavior)

**Root Cause**: 
- orders-db: 1 replica (severe bottleneck)
- carts-db: 2 replicas (moderate bottleneck)
- All application replicas contending for same database instance

**Solution**: Scaled databases to 3 replicas

**Result After Fix**:
- Carts: 33% improvement when scaling (53.2ms → 35.5ms)
- Orders: 45% improvement when scaling (78.7ms → 43.7ms)

**Implication**: Application-tier autoscaling is ineffective when database tier is bottlenecked. This is a valid research finding.

### Finding 2: SLO Threshold Too Aggressive
**Issue**: 36ms SLO threshold causes 90% violation rate even after scaling

**Analysis**:
- 36ms was derived from training data (P75 of P95 latency under 50-user constant load)
- Training environment had ~12% violation rate
- Testing with 150 users (3x load) results in 90% violations
- Database operations inherently take 45-50ms under load

**Options**:
1. Adjust SLO to 50-60ms (realistic for database operations)
2. Document that 36ms is achievable for stateless services only
3. Use different SLOs per service type (stateless vs database-backed)

### Finding 3: Convergence Requires Time
**Issue**: 10-minute tests too short to show convergence

**Analysis**:
- System needs 5-10 minutes to scale up
- Pods take 60s to start
- Cooldown periods prevent rapid scaling
- Need 20+ minute tests to observe steady state

**Solution**: Implemented 20-minute convergence tests with 40 snapshots

### Finding 4: Timing Bug in Experiments
**Issue**: Last 6-9 snapshots always showed no violations

**Root Cause**: Sleep-first collection pattern
- Locust runs for N minutes
- First snapshot at 0:30, last at N:00
- But that's N:30 after Locust start
- Locust stops at N:00, so last snapshots measure no-load

**Solution**: Increase Locust duration by 1 minute (N+1 minutes for N-minute test)

---

## 📊 Current System State

### GCP Resources
- **Project**: grad-phca
- **Cluster**: pipeline-cluster (3 nodes, n1-standard-2)
- **Zone**: us-central1-a
- **Locust VM**: 35.222.116.125 (n1-standard-2)

### Deployed Services

#### Sock Shop (namespace: sock-shop)
| Service | Replicas | Database | Status |
|---------|----------|----------|--------|
| front-end | Variable (1-6) | None | ✅ Working |
| carts | Variable (1-5) | carts-db (3) | ✅ Working |
| orders | Variable (1-5) | orders-db (3) | ✅ Working |
| catalogue | Variable (1-2) | catalogue-db (1) | ✅ Working |
| user | Variable (1-5) | user-db (1) | ✅ Working |
| payment | Variable (1-2) | None | ✅ Working |
| shipping | Variable (1-3) | None | ✅ Working |

#### ML Pipeline (namespace: kafka)
| Service | Replicas | Status |
|---------|----------|--------|
| metrics-aggregator | 1 | ✅ Working |
| ml-inference-svm | 1 | ✅ Working |
| ml-inference-lr | 1 | ✅ Working |
| ml-inference-rf | 1 | ✅ Working |
| authoritative-scaler | 1 | ✅ Working |
| scaling-controller | 0/1 | ⚠️ Toggle for proactive/reactive |
| kafka | 1 | ✅ Working |
| zookeeper | 1 | ✅ Working |

#### Monitoring (namespace: monitoring)
| Service | Status |
|---------|--------|
| prometheus | ✅ Working (34.170.213.190:9090) |

### Configuration
- **SLO Threshold**: 36ms (may need adjustment)
- **Load Test**: 150 users constant
- **Collection Interval**: 30 seconds
- **Test Duration**: 6 minutes (quick) or 20 minutes (convergence)

---

## ⚠️ Known Issues

### 1. Prometheus Timeouts Under Heavy Load
**Symptom**: Query timeouts during metrics collection  
**Workaround**: Increase timeout from 5s to 15s  
**Status**: Needs permanent fix

### 2. Application Errors (~5% rate)
**Symptom**: 500 errors on add_to_cart, checkout, clear_cart  
**Root Cause**: Locust test design (race conditions, "Cannot find item in cart")  
**Impact**: Not a scaling issue, but affects test validity  
**Status**: Acceptable for research (real-world systems have errors)

### 3. HPA Scale-Down Behavior
**Symptom**: Reactive HPA scales down aggressively after load stops  
**Impact**: Final snapshots show low replica counts  
**Status**: Expected behavior, not a bug

### 4. Unicode Characters in Windows Terminal
**Symptom**: Checkmark/X characters cause crashes  
**Fix**: Replaced with "OK"/"FAIL" text  
**Status**: ✅ Fixed

---

## 📈 Test Results Summary

### Recent Tests (with scaled databases)
- **proactive_constant_run01**: 10 snapshots, databases scaled
  - Carts: 2→3 replicas, 33% improvement
  - Orders: 2→3 replicas, 45% improvement
  - Shows database scaling fixed bottleneck

### Earlier Tests (without scaled databases)
- **proactive_constant_run01** (20-min): 40 snapshots, 31 valid
  - Showed database bottleneck clearly
  - Orders latency INCREASED with more replicas
  - Used for bottleneck analysis

### Test Files Location
`kafka-structured/experiments/results/*.jsonl`

---

## 🎯 Next Steps (Priority Order)

### High Priority
1. **Run 20-minute convergence test** with scaled databases
   - Goal: Show violations converge to <10% in final 5 minutes
   - Compare proactive vs reactive
   - This is the KEY result for the paper

2. **Adjust SLO threshold** if needed
   - Option A: Keep 36ms, document limitations
   - Option B: Adjust to 50-60ms for database services
   - Option C: Per-service SLOs

3. **Run full experiment suite**
   - All 4 load patterns (constant, step, spike, ramp)
   - Both conditions (proactive, reactive)
   - Multiple repetitions for statistical significance

### Medium Priority
4. **Fix Prometheus timeout issue**
   - Increase timeout to 15s
   - Or optimize queries
   - Or add retry logic

5. **Analyze results**
   - Calculate aggregate metrics
   - Statistical significance tests
   - Generate comparison graphs

6. **Write paper sections**
   - Methodology
   - Results
   - Discussion (database bottleneck finding)

### Low Priority
7. **Consider database autoscaling**
   - Add databases to monitored services
   - Train models with database features
   - Implement database scaling logic

8. **Optimize costs**
   - Shut down resources when not testing
   - Use preemptible nodes
   - Clean up old resources

---

## 📝 Documentation Status

### Completed Documentation
- ✅ `GRADMATE_ACCESS_SETUP.md` - Complete setup guide
- ✅ `ACCESS_GRANTED_SUMMARY.md` - Access summary
- ✅ `DATABASE_BOTTLENECK_ANALYSIS.md` - Bottleneck findings
- ✅ `DATABASE_SCALING_PLAN.md` - Scaling plan
- ✅ `CONVERGENCE_TEST_PLAN.md` - Test methodology
- ✅ `PROJECT_STATUS.md` - This file

### Code Documentation
- ⚠️ Inline comments exist but could be improved
- ⚠️ README files in subdirectories need updates
- ⚠️ API documentation missing

---

## 💰 Cost Tracking

### Current Monthly Costs (Estimate)
- GKE cluster (3 nodes): ~$150/month
- Locust VM: ~$50/month
- Storage: ~$10/month
- Networking: ~$20/month
- **Total**: ~$230/month

### Cost Optimization
- Stop Locust VM when not testing: Save $35/month
- Scale cluster to 1 node when not testing: Save $100/month
- Delete old container images: Save $5/month

---

## 🔐 Security & Access

### Current Access
- **Owner**: ahmody.ossama@gmail.com
- **Editor**: ahmedd.eldarawi@gmail.com (full access granted)

### Service Accounts
- Default compute service account
- GKE node service account
- Cloud Build service account

### SSH Keys
- Shared SSH key for Locust VM access
- Located in `~/.ssh/google_compute_engine`

---

## 📚 References

### Papers
- EuroSys'24: "Erlang: Application-Aware Autoscaling for Cloud Microservices"
- Original inspiration for this work

### Technologies
- Kubernetes: Container orchestration
- Prometheus: Metrics collection
- Kafka: Message streaming
- Locust: Load testing
- Scikit-learn: ML models

### Repositories
- Sock Shop: https://github.com/microservices-demo/microservices-demo
- Locust: https://locust.io/

---

**Last Updated**: April 12, 2026  
**Status**: Ready for handoff  
**Next Milestone**: Convergence test results
